tipos = (
    ('R', 'Residente'),
    ('V', 'Visita'),
)